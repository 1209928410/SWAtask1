package com.rhwayfun.service;


public interface HelloService {

	String getName();
}
