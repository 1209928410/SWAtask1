package com.rhwayfun.service.impl;

import com.rhwayfun.service.HelloService;


public class HelloServiceImpl implements HelloService {

	public String getName() {
		return "rhwayfun";
	}

}
