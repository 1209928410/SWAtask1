﻿一个基于dubbo的分布式服务框架

分为两个简单服务

在consumer里面为启动hello服务
在provider里面为提供任务名

连接为consumer下的DubboConsumerDemo获取远程服务再进行注册服务


实现为apptest.java里面的服务提供者已注册