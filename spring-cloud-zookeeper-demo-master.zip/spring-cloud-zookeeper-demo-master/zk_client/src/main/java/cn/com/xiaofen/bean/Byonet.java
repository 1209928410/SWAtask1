package cn.com.xiaofen.bean;

public class Byonet {
	private String kkid;
	private String kkmc;
	private String x;
	private String y;
	public String getKkid() {
		return kkid;
	}
	public void setKkid(String kkid) {
		this.kkid = kkid;
	}
	public String getKkmc() {
		return kkmc;
	}
	public void setKkmc(String kkmc) {
		this.kkmc = kkmc;
	}
	public String getX() {
		return x;
	}
	public void setX(String x) {
		this.x = x;
	}
	public String getY() {
		return y;
	}
	public void setY(String y) {
		this.y = y;
	}
	
	
}
