package com.demo.web.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "/helloworld")
public class HelloWorldController {

    @RequestMapping(value="/index", method = {RequestMethod.GET})
    public ModelAndView index(){
        
        ModelAndView modelAndView = new ModelAndView();   
        modelAndView.addObject("message", "our LGD is unstopable!!!!");  
        modelAndView.addObject("image", "1.png");
        modelAndView.setViewName("index");  
        return modelAndView;
    }
    
}